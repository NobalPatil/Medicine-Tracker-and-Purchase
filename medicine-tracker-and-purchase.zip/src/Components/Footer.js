import "font-awesome/css/font-awesome.min.css";
import "../CSS/Footer.css";
export function Footer() {
  return (
    <footer
      class=" Footer stick-bottom  text-center text-white "
      style={{ background: "rgb(30, 30, 30)" }}
    >
      <div class="container-fluid p-1">
        <a
          class="btn btn-outline-light btn-floating m-2"
          href="https://www.facebook.com/login.php"
          type="button"
        >
          <i class="fa fa-facebook-f"></i>
        </a>

        <a
          class="btn btn-outline-light btn-floating m-2"
          href="https://twitter.com/login/"
          type="button"
        >
          <i class="fa fa-twitter"></i>
        </a>

        <a
          class="btn btn-outline-light btn-floating m-2"
          href="https://myaccount.google.com/"
          Type="button"
        >
          <i class="fa fa-google"></i>
        </a>

        <a
          class="btn btn-outline-light btn-floating m-2"
          href="https://www.instagram.com"
          type="button"
        >
          <i class="fa fa-instagram"></i>
        </a>

        <a
          class="btn btn-outline-light btn-floating m-2"
          href="https://www.linkedin.com/uas/login"
          type="button"
        >
          <i class="fa fa-linkedin"></i>
        </a>

        <a
          class="btn btn-outline-light btn-floating m-2"
          href="https://github.com/login"
          type="button"
        >
          <i class="fa fa-github"></i>
        </a>
      </div>
      <div>
        <h2>MedTrack Online Order & Purchase</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua.
          <br /> Ut enim ad minim veniam, quis nostrud exercitation ullamco
          laboris
          <br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco
        </p>
        <p>Gmail: medtracksupport@gmail.com</p>
      </div>

      <div class="text-center p-1">
        © 2022 Copyright :
        <a class="text-white" href="localhost:3000">
          {" "}
          MedTrack.com
        </a>
      </div>
      <br />
    </footer>
  );
}
