import "bootstrap/dist/css/bootstrap.min.css";
import { Carousel } from "react-bootstrap";
import swal from "sweetalert";
import NavBar from "./CustomerComponents/CustomerNavBar";
import Navbar from "./PharmacistComponents/PharmacistNavBar";

function ContactUs() {
  return (
    <>
      {localStorage.getItem("customer") != null ||
      localStorage.getItem("pharmacist") != null ? (
        <div>
          {localStorage.getItem("customer") != null ? (
            <NavBar />
          ) : localStorage.getItem("pharmacist") != null ? (
            <Navbar />
          ) : (
            ""
          )}
          <div className="bg-light">
            <div style={{ fontFamily: "Block" }}>
              <br />
              <br />
              <br />
              <h2>
                Our Offices
                <hr />
                <br />
              </h2>

              <h6>
                aqwerrssippi
                <br />
                <br />
                711-2880 Nulla St. Mankato Mississippi 96522 (257)
                5fsfgfdg63-7401
                <br />
                <br />
                qqaazsisppi
                <br />
                <br />
                711-2880 Nulla St. Mankato Misssasssissippi 96522 (257)
                563asasd-7401
                <br />
                <br />
                Missisdasfad
                <br />
                <br />
                711-2880 Nulla St. Mankato Madasdississippi 96522 (257) 563-7401
                <br />
                <br />
                lasdwertyu
                <br />
                <br />
                711-2880 Nulla St. Mankatoasdasd Mississippi 96522 (257)
                563asdsd-7401
                <br />
                <br />
                Mexicxsacsad
                <br />
                <br />
                191-103 Integer Rd. Corona New Masdasdexico 08219 (404)
                960sadas-3807
              </h6>
              <br />
              <br />
              <br />
            </div>
          </div>

          <br />
          <br />
          <br />
          <br />
          <div>
            <br />
            {<div class="container-md"></div>}
          </div>
        </div>
      ) : (
        swal({
          icon: "error",
          text: "You are not logged in!",
          type: "error",
          timer: 3000,
        }).then(function () {
          window.location.href = "/login-page";
        })
      )}
    </>
  );
}

export default ContactUs;
