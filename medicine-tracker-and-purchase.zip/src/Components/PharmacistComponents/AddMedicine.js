import "bootstrap/dist/css/bootstrap.css";
import { useState } from "react";
import swal from "sweetalert";
import axios from "axios";
import Navbar from "./PharmacistNavBar";

export default function AddMedicine() {
  const [medName, setMedName] = useState("");
  const [medManufacturer, setMedManufacturer] = useState("");
  const [medCost, setMedCost] = useState(0);
  const [medUse, setMedUse] = useState("");
  const [isInStock, setIsInStock] = useState(false);

  const handleForm = (e) => {
    e.preventDefault();
    if (
      medName === "" ||
      medManufacturer === "" ||
      medCost === "" ||
      medUse === "" ||
      isInStock === ""
    ) {
      swal("Error", "Please enter details", "error");
    } else {
      addMedicine();
    }
  };

  const addMedicine = () => {
    const med = {
      medName: medName,
      medManufacturer: medManufacturer,
      medCost: medCost,
      medUse: medUse,
      isInStock: isInStock,
      pharmacist: JSON.parse(localStorage.getItem("pharmacist")),
    };

    axios
      .post("http://localhost:8081/add-medicine", med)
      .then((res) => {
        if (Object.keys(res.data).length) {
          swal("success", " Medicine added Successfully!", "success", {
            timer: 2000,
          }).then(() => (window.location.href = "/add-medicine"));
        } else
          swal("Something went wrong", "Please try again!", "error", {
            timer: 2000,
          });
      })
      .catch(() =>
        swal("Something went wrong", "Please try again!", "error", {
          timer: 2000,
        })
      );
  };

  return (
    <>
      {localStorage.getItem("pharmacist") != null ? (
        <div>
          <Navbar />
          <div
            class="container mt-4 mb-4"
            style={{ border: "2px solid black" }}
          >
            <div class="row">
              <div class="col-2 "></div>
              <div class="col-8">
                <div class="row">
                  <div class="col-2"></div>
                  <div class="col-md-8">
                    <div class="do">
                      <form class="form-group">
                        <div class="inside-form mt-3" style={{ color: "dark" }}>
                          <center>
                            <h2>
                              <b>Add Medicines</b>
                            </h2>
                          </center>
                        </div>
                        <div class="form-group ">
                          <label
                            id="sty"
                            style={{
                              fontSize: "14px",
                              backgroundColor: "#99ebff",
                            }}
                          >
                            Medicine Details
                          </label>
                        </div>
                        <div class="form-group ">
                          <label for="" id="sty">
                            Medicine Name <span>*</span>
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            id="medName"
                            name="medName"
                            placeholder="enter Medicine Name"
                            onChange={(e) => {
                              setMedName(e.target.value);
                            }}
                          />
                          <span id="errormsg"></span>
                        </div>

                        <div class="form-group ">
                          <label for="" id="sty">
                            Manufacturer Name <span>*</span>
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            id="medManufacturer"
                            name="medManufacturer"
                            placeholder="enter medicine manufacturer name"
                            onChange={(e) => {
                              setMedManufacturer(e.target.value);
                            }}
                          />
                          <span id="errormsg"></span>
                        </div>
                        <br />

                        <div class="form-group ">
                          <label for="" id="sty">
                            Medicine Cost (per strip/item)<span>*</span>
                          </label>
                          <textarea
                            class="form-control"
                            rows="1"
                            itemType="number"
                            id="medCost"
                            name="medCost"
                            placeholder="enter medicine cost"
                            onChange={(e) => {
                              setMedCost(e.target.value);
                            }}
                          ></textarea>
                        </div>
                        <br />

                        <div class="form-group ">
                          <label for="" id="sty">
                            Medicine Use<span>*</span>
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            id="medUse"
                            name="medUse"
                            onChange={(e) => {
                              setMedUse(e.target.value);
                            }}
                          />
                          <span id="errormsg1"></span>
                        </div>

                        <div class="form-group ">
                          <label for="" id="sty">
                            In Stock?<span>*</span>
                          </label>

                          <div class="custom-control custom-switch">
                            <input
                              type="checkbox"
                              class="custom-control-input"
                              id="isInStock"
                              name="isInStock"
                              onClick={() => setIsInStock(!isInStock)}
                            />
                          </div>

                          <span id="errormsg1"></span>
                        </div>

                        <div class="form-group ">
                          <span id="errormsg1"></span>
                        </div>

                        <div class="form-group ">
                          <button
                            class="btn btn-success mt-2"
                            type="submit"
                            onClick={handleForm}
                            style={{ fontSize: "15px" }}
                          >
                            Add
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        swal({
          icon: "error",
          text: "You are not logged in!",
          type: "error",
          timer: 3000,
        }).then(function () {
          window.location.href = "/login-page";
        })
      )}
    </>
  );
}
