import axios from "axios";
import { useState } from "react";
import swal from "sweetalert";
import "bootstrap/dist/css/bootstrap.css";
import "../../CSS/PharmacistRegistration.css";
import { Link } from "react-router-dom";

export default function PharmacistRegistration() {
  const [pharmacistName, setPharmacistName] = useState("");
  const [pharmacyName, setPharmacyName] = useState("");
  const [pharmacyAddress, setPhmAddress] = useState("");
  const [pharmacyLatitude, setLat] = useState(0);
  const [pharmacyLongitude, setLng] = useState(0);
  const [pharmacistMobNo, setPhmMobno] = useState("");
  const [pharmacistEmailId, setPhmEmail] = useState("");
  const [pharmacistPassword, setPhmPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const getCoordinates = (position) => {
    setLat(position.coords.latitude);
    setLng(position.coords.longitude);
  };

  const regex =
    /^([a-zA-Z0-9_\.\-\ ])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  const regex1 = /^([a-zA-Z\ ])+$/;
  const regex2 = /^[6-9]{1}[0-9]{9}$/;

  const handleForm = (e) => {
    e.preventDefault();
    if (
      pharmacistName === "" ||
      pharmacyName === "" ||
      pharmacyAddress === "" ||
      pharmacistMobNo === "" ||
      pharmacistEmailId === "" ||
      pharmacistPassword === ""
    ) {
      swal("error", "please enter details", "error");
    } else if (!regex1.test(pharmacyName)) {
      swal("Error!", "Please Enter valid Name", "error");
    } else if (!regex.test(pharmacistEmailId)) {
      swal("Error!", "Please Enter Valid Email Address", "error");
    } else if (
      pharmacistPassword.length < 8 ||
      pharmacistPassword.length > 20
    ) {
      swal("Error!", "Password length is min 8 and max length is 20", "error");
    } else if (
      !regex2.test(pharmacistMobNo) ||
      pharmacistMobNo.length < 10 ||
      pharmacistMobNo.length > 10
    ) {
      swal("Error!!", "Please Enter valid mobile number", "error");
    } else if (confirmPassword != pharmacistPassword) {
      swal("Error!", "Password does not match", "error");
    } else {
      addPharmacist();
    }
  };

  const addPharmacist = () => {
    const pharma = {
      pharmacistName: pharmacistName,
      pharmacyName: pharmacyName,
      pharmacyAddress: pharmacyAddress,
      pharmacyLatitude: pharmacyLatitude,
      pharmacyLongitude: pharmacyLongitude,
      pharmacistMobNo: pharmacistMobNo,
      pharmacistEmailId: pharmacistEmailId,
      pharmacistPassword: pharmacistPassword,
    };

    axios
      .post("http://localhost:8081/register-pharmacist", pharma)
      .then((res) => {
        if (Object.keys(res.data).length) {
          swal(
            "success",
            " Your Registration Completed Successfully",
            "success",
            {
              timer: 2000,
            }
          ).then(() => (window.location.href = "/login-page"));
        } else
          swal("Error", "Something went wrong, please try again", "error", {
            timer: 2000,
          });
      })
      .catch(() =>
        swal("Error", "Something went wrong, please try again", "error", {
          timer: 2000,
        })
      );
  };

  return (
    <>
      {navigator.geolocation.getCurrentPosition(getCoordinates)}
      <div class="container mt-4 mb-4" style={{ border: "2px solid black" }}>
        <div class="row">
          <div class="col-2 "></div>
          <div class="col-8">
            <div class="row">
              <div class="col-2"></div>
              <div class="col-md-8">
                <div class="do">
                  <form class="form-group">
                    <div class="inside-form mt-3" style={{ color: "dark" }}>
                      <center>
                        <h2>
                          <b>Pharmacist Registration</b>
                        </h2>
                      </center>
                    </div>
                    <div class="form-group ">
                      <label
                        id="sty"
                        style={{
                          fontSize: "14px",
                          backgroundColor: "#99ebff",
                        }}
                      >
                        Personal Details
                      </label>
                    </div>
                    <div class="form-group ">
                      <label for="" id="sty">
                        Pharmacist Name <span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="PharmacistName"
                        name="pharmacistName"
                        placeholder="enter your name"
                        onChange={(e) => {
                          setPharmacistName(e.target.value);
                        }}
                      />
                      <span id="errormsg"></span>
                    </div>

                    <div class="form-group ">
                      <label for="" id="sty">
                        Pharmacy Name <span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="PharmacyName"
                        name="pharmacyName"
                        placeholder="enter your pharmacy name"
                        onChange={(e) => {
                          setPharmacyName(e.target.value);
                        }}
                      />
                      <span id="errormsg"></span>
                    </div>
                    <br />

                    <div class="form-group ">
                      <label for="" id="sty">
                        Pharmacy Address<span>*</span>
                      </label>
                      <textarea
                        class="form-control"
                        rows="1"
                        id="PharmacyAddress"
                        name="pharmacyAddress"
                        placeholder="enter your pharmacy Address"
                        onChange={(e) => {
                          setPhmAddress(e.target.value);
                        }}
                      ></textarea>
                    </div>
                    <br />

                    <div class="form-group ">
                      <label for="" id="sty">
                        Pharmacist mobileNo<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="PharmacistmobileNo"
                        name="pharmacistMobNo"
                        placeholder="enter your ContactNo"
                        onChange={(e) => {
                          setPhmMobno(e.target.value);
                        }}
                      />
                      <span id="errormsg1"></span>
                    </div>

                    <div class="col info-row">
                      <label
                        class="text"
                        id="sty"
                        style={{
                          fontSize: "14px",
                          backgroundColor: "#99ebff",
                        }}
                      >
                        Registration Info
                      </label>
                    </div>

                    <div class="form-group ">
                      <label for="email" id="sty" style={{ fontSize: "15px" }}>
                        Email Id:<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="email"
                        name="pharmacistEmailId"
                        style={{ fontSize: "15px" }}
                        placeholder="enter your Email"
                        onChange={(e) => {
                          setPhmEmail(e.target.value);
                        }}
                      />
                      <span id="errormsg3"></span>
                    </div>

                    <div class="form-group ">
                      <label
                        for="password"
                        id="sty"
                        style={{ fontSize: "15px" }}
                      >
                        Password:<span>*</span>
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="password"
                        name="pharmacistPassword"
                        style={{ fontSize: "15px" }}
                        placeholder="enter Password"
                        onChange={(e) => {
                          setPhmPassword(e.target.value);
                        }}
                      />
                      <span id="errormsg4"></span>
                      <span id="errormsg4"></span>
                    </div>
                    <div class="form-group ">
                      <label
                        for="confirmPassword"
                        id="sty"
                        style={{ fontSize: "15px" }}
                      >
                        Confirm Password:<span>*</span>
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="confirmPassword"
                        onChange={(e) => {
                          setConfirmPassword(e.target.value);
                        }}
                        style={{ fontSize: "15px" }}
                        placeholder="confirm Password"
                      />
                      <span id="errormsg5"></span>
                    </div>

                    <div class="form-group ">
                      <button
                        class="btn btn-success mt-2"
                        type="submit"
                        onClick={handleForm}
                        style={{ fontSize: "15px" }}
                      >
                        Submit
                      </button>
                      <div id="sty">
                        <label>Already have account ? </label>
                        <Link to="/login-page" style={{ color: "black" }}>
                          Login Here
                        </Link>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
