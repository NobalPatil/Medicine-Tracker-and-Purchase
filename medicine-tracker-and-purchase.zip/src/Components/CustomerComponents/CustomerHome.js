import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import { Carousel } from "react-bootstrap";
import "../../CSS/CustomerHome.css";
import one from "../../Images/aayu.jpg";
import two from "../../Images/Acetaminophen.jpg";
import three from "../../Images/Paracetamol.jpg";
import four from "../../Images/cancerdrug.jpg";
import five from "../../Images/medicine5.jpg";
import six from "../../Images/apollo.jpg";
import NavBar from "./CustomerNavBar";
import swal from "sweetalert";

function CustomerHome() {
  return (
    <>
      {localStorage.getItem("customer") != null ? (
        <div>
          <NavBar />
          <div class="main" style={{ bgcolor: "orange" }}>
            <Carousel>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={one}
                  height={500}
                  width={1000}
                  alt="First slide"
                />
                <Carousel.Caption>
                  <h3>First slide label</h3>
                  <p>
                    Nulla vitae elit libero, a pharetra augue mollis interdum.
                  </p>
                </Carousel.Caption>
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={two}
                  height={500}
                  width={1000}
                  alt="Second slide"
                />

                <Carousel.Caption>
                  <h3>Second slide label</h3>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </p>
                </Carousel.Caption>
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={three}
                  height={500}
                  width={1000}
                  alt="Third slide"
                />

                <Carousel.Caption>
                  <h3>Third slide label</h3>
                  <p>
                    Praesent commodo cursus magna, vel scelerisque nisl
                    consectetur.
                  </p>
                </Carousel.Caption>
              </Carousel.Item>
            </Carousel>

            <section class="bannerbottom py-lg-5 py-md-4 py-md-3 py-2">
              <div class="bannerbottom py-lg-5 py-md-4 py-md-3 py-2">
                <div class="container">
                  <div class="row">
                    <div class="col-md-4 col-sm-12 w3_ban1">
                      <div class="card">
                        <img
                          src={one}
                          class="card-img-top"
                          alt="Card image cap"
                        />
                        <div class="card-body">
                          <h5 class="card-title">Ayurveda</h5>
                          <p class="card-text">
                            This Indian system of medicine has unique
                            distinction of having six recognised systems which
                            are Ayurveda, Siddha, Unani and Yoga, Naturopathy
                            and Homeopathy.
                          </p>
                          <a
                            href="https://www.hopkinsmedicine.org/health/wellness-and-prevention/ayurveda#:~:text=What%20is%20Ayurveda%3F,translates%20to%20knowledge%20of%20life."
                            class="btn btn-primary"
                          >
                            Learn more
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-12 w3_ban1">
                      <div class="card">
                        <img
                          class="card-img-top"
                          src={five}
                          alt="Card image cap"
                        />
                        <div class="card-body">
                          <h5 class="card-title">Medicine</h5>
                          <p class="card-text">
                            It covers diagnosis, treatment, and prevention of
                            disease, medical research, and many other aspects of
                            health.
                          </p>
                          <a
                            href="https://lww.com/pages/default.aspx?ContextUrl=%2fpages%2fdefault.aspx&utm_source=housead&utm_medium=display&utm_campaign=health_hlrp_pr_medpr_1-q138"
                            class="btn btn-primary"
                          >
                            Learn more
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-12 w3_ban1">
                      <div class="card">
                        <img
                          class="card-img-top"
                          src={three}
                          alt="Card image cap"
                        />
                        <div class="card-body">
                          <h5 class="card-title">Paracetamol</h5>
                          <p class="card-text">
                            Paracetamol is a common painkiller used to treat
                            aches and pain.and the benefits of its use for fever
                            It can also be used to reduce a high temperature.
                          </p>
                          <a
                            href="https://www.nhs.uk/medicines/paracetamol-for-adults/"
                            class="btn btn-primary"
                          >
                            Learn more
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-12 w3_ban">
                      <div class="card">
                        <img
                          class="card-img-top"
                          src={six}
                          alt="Card image cap"
                        />
                        <div class="card-body">
                          <h5 class="card-title">pharmacy</h5>
                          <p class="card-text">
                            Apollo Pharmacy is your go-to online pharmacy store
                            for all your medicine needs – be it your regular or
                            over-the-counter (OTC) medicines.
                          </p>
                          <a
                            href="https://en.wikipedia.org/wiki/Pharmacy"
                            class="btn btn-primary"
                          >
                            Learn more
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-12 w3_ban">
                      <div class="card">
                        <img
                          class="card-img-top"
                          src={two}
                          alt="Card image cap"
                        />
                        <div class="card-body">
                          <h5 class="card-title">Acetaminophen</h5>
                          <p class="card-text">
                            Acetaminophen is used to relieve mild to moderate
                            pain from headaches,colds and to reduce fever.
                          </p>
                          <a
                            href="https://www.webmd.com/drugs/2/drug-362/acetaminophen-oral/details"
                            class="btn btn-primary"
                          >
                            Learn more
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-12 w3_ban">
                      <div class="card">
                        <img
                          class="card-img-top"
                          src={four}
                          alt="Card image cap"
                        />
                        <div class="card-body">
                          <h5 class="card-title">Cancer Drug</h5>
                          <p class="card-text">
                            Oral chemotherapy is a cancer-fighting drug given by
                            mouth in tablet, capsule, nurse practitioner, or
                            physician's assistant, or liquid form.
                          </p>
                          <a
                            href="https://www.cancer.gov/about-cancer/treatment/drugs"
                            class="btn btn-primary"
                          >
                            Learn more
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      ) : (
        swal({
          icon: "error",
          text: "You are not logged in!",
          type: "error",
          timer: 3000,
        }).then(function () {
          window.location.href = "/login-page";
        })
      )}
    </>
  );
}
export default CustomerHome;
