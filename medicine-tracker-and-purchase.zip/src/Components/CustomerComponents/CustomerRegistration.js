import axios from "axios";
import { useState } from "react";
import swal from "sweetalert";
import "bootstrap/dist/css/bootstrap.css";
import "../../CSS/PharmacistRegistration.css";
import { Link } from "react-router-dom";

export default function CustomerRegistration() {
  const [custName, setCustName] = useState("");
  const [custAddress, setCustAddress] = useState("");
  const [custMobNo, setCustMobno] = useState("");
  const [custEmailId, setCustEmail] = useState("");
  const [custPassword, setCustPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const regex =
    /^([a-zA-Z0-9_\.\-\ ])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  const regex1 = /^([a-zA-Z\ ])+$/;
  const regex2 = /^[6-9]{1}[0-9]{9}$/;

  const handleForm = (e) => {
    e.preventDefault();
    if (
      custName === "" ||
      custAddress === "" ||
      custMobNo === "" ||
      custEmailId === "" ||
      custPassword === ""
    ) {
      swal("Error!", "Please enter details", "error");
    } else if (!regex1.test(custName)) {
      swal("Error!", "Please enter valid name", "error");
    } else if (!regex.test(custEmailId)) {
      swal("Error!", "Please enter valid email address", "error");
    } else if (custPassword.length < 8 || custPassword.length > 20) {
      swal("Error!", "Password length is min 8 and max length is 20", "error");
    } else if (
      !regex2.test(custMobNo) ||
      custMobNo.length < 10 ||
      custMobNo.length > 10
    ) {
      swal("Error!", "Please enter valid mobile number", "error");
    } else if (confirmPassword != custPassword) {
      swal("Error!", "Password does not match", "error");
    } else {
      addCustomer();
    }
  };

  const addCustomer = () => {
    const customer = {
      custName: custName,
      custAddress: custAddress,
      custMobNo: custMobNo,
      custEmailId: custEmailId,
      custPassword: custPassword,
    };

    axios
      .post("http://localhost:8081/register-customer", customer)
      .then((res) => {
        if (Object.keys(res.data).length) {
          swal(
            "success",
            " Your Registration Completed Successfully",
            "success",
            {
              timer: 2000,
            }
          ).then(() => (window.location.href = "/login-page"));
        } else
          swal("Error", "Something went wrong, please try again", "error", {
            timer: 2000,
          });
      })
      .catch(() =>
        swal("Error", "Something went wrong, please try again", "error", {
          timer: 2000,
        })
      );
  };

  return (
    <>
      <div class="container mt-4 mb-4" style={{ border: "2px solid black" }}>
        <div class="row">
          <div class="col-2 "></div>
          <div class="col-8">
            <div class="row">
              <div class="col-2"></div>
              <div class="col-md-8">
                <div class="do">
                  <form class="form-group">
                    <div class="inside-form mt-3" style={{ color: "dark" }}>
                      <center>
                        <h2>
                          <b>Customer Registration</b>
                        </h2>
                      </center>
                    </div>
                    <div class="form-group ">
                      <label
                        id="sty"
                        style={{
                          fontSize: "14px",
                          backgroundColor: "#99ebff",
                        }}
                      >
                        Personal Details
                      </label>
                    </div>
                    <div class="form-group ">
                      <label for="" id="sty">
                        Customer Name <span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="CustomerName"
                        name="customerName"
                        placeholder="enter your name"
                        onChange={(e) => {
                          setCustName(e.target.value);
                        }}
                      />
                      <span id="errormsg"></span>
                    </div>

                    <br />

                    <div class="form-group ">
                      <label for="" id="sty">
                        Customer Address<span>*</span>
                      </label>
                      <textarea
                        class="form-control"
                        rows="1"
                        id="CustomerAddress"
                        name="customerAddress"
                        placeholder="enter your Address"
                        onChange={(e) => {
                          setCustAddress(e.target.value);
                        }}
                      ></textarea>
                    </div>
                    <br />

                    <div class="form-group ">
                      <label for="" id="sty">
                        Customer mobileNo<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="CustomerMobileNo"
                        name="customerMobNo"
                        placeholder="enter your ContactNo"
                        onChange={(e) => {
                          setCustMobno(e.target.value);
                        }}
                      />
                      <span id="errormsg1"></span>
                    </div>

                    <div class="col info-row">
                      <label
                        class="text"
                        id="sty"
                        style={{
                          fontSize: "14px",
                          backgroundColor: "#99ebff",
                        }}
                      >
                        Registration Info
                      </label>
                    </div>

                    <div class="form-group ">
                      <label for="email" id="sty" style={{ fontSize: "15px" }}>
                        Email Id:<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="email"
                        name="customerEmailId"
                        style={{ fontSize: "15px" }}
                        placeholder="enter your Email"
                        onChange={(e) => {
                          setCustEmail(e.target.value);
                        }}
                      />
                      <span id="errormsg3"></span>
                    </div>

                    <div class="form-group ">
                      <label
                        for="password"
                        id="sty"
                        style={{ fontSize: "15px" }}
                      >
                        Password:<span>*</span>
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="password"
                        name="customerPassword"
                        style={{ fontSize: "15px" }}
                        placeholder="enter Password"
                        onChange={(e) => {
                          setCustPassword(e.target.value);
                        }}
                      />
                      <span id="errormsg4"></span>
                      <span id="errormsg4"></span>
                    </div>
                    <div class="form-group ">
                      <label
                        for="confirmPassword"
                        id="sty"
                        style={{ fontSize: "15px" }}
                      >
                        Confirm Password:<span>*</span>
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="confirmPassword"
                        onChange={(e) => {
                          setConfirmPassword(e.target.value);
                        }}
                        style={{ fontSize: "15px" }}
                        placeholder="confirm Password"
                      />
                      <span id="errormsg5"></span>
                    </div>

                    <div class="form-group ">
                      <button
                        class="btn btn-success mt-2"
                        type="submit"
                        onClick={handleForm}
                        style={{ fontSize: "15px" }}
                      >
                        Submit
                      </button>
                      <div id="sty">
                        <label>Already have account ? </label>
                        <Link to="/login-page" style={{ color: "black" }}>
                          Login Here
                        </Link>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
