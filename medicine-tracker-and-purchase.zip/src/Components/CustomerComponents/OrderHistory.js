import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import swal from "sweetalert";
import NavBar from "./CustomerNavBar";

export default function OrderHistory() {
  const orders = JSON.parse(localStorage.getItem("orders"));

  return (
    <>
      {localStorage.getItem("customer") != null ? (
        <div>
          <NavBar />
          <div class="row">
            {orders.map((ordr, key) => {
              return (
                <div
                  key={key}
                  class="card m-auto mb-3 card-text d-flex"
                  style={{ width: "400px", padding: "10px" }}
                >
                  <th style={{ fontSize: "22px", color: "#000075" }}>
                    Order Date :{ordr.orderDate}
                  </th>
                  <hr />
                  <th style={{ fontSize: "22px" }}>
                    Medicine :{ordr.medicine.medName}
                  </th>
                  <th style={{ fontSize: "22px" }}>
                    Manufacturer :{ordr.medicine.medManufacturer}
                  </th>
                  <th style={{ fontSize: "22px" }}>
                    Medicine Cost :{ordr.medicine.medCost}
                  </th>
                  <th style={{ fontSize: "22px" }}>
                    Order Quantity :{ordr.orderQuantity} (strips/items)
                  </th>
                  <th style={{ fontSize: "22px" }}>
                    Order Price :{ordr.orderPrice}
                  </th>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        swal({
          icon: "error",
          text: "You are not logged in!",
          type: "error",
          timer: 3000,
        }).then(function () {
          window.location.href = "/login-page";
        })
      )}
    </>
  );
}
