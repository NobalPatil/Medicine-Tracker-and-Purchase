import "bootstrap/dist/css/bootstrap.min.css";
import swal from "sweetalert";
import NavBar from "./CustomerComponents/CustomerNavBar";
import Navbar from "./PharmacistComponents/PharmacistNavBar";

function AboutUs() {
  return (
    <>
      {localStorage.getItem("customer") != null ||
      localStorage.getItem("pharmacist") != null ? (
        <div>
          {localStorage.getItem("customer") != null ? (
            <NavBar />
          ) : localStorage.getItem("pharmacist") != null ? (
            <Navbar />
          ) : (
            ""
          )}

          <div class="d-flex justify-content-center bg-light">
            {
              <div>
                <div class="d-flex justify-content-center">
                  <div className="" style={{ fontFamily: "Block" }}>
                    <br></br>

                    <br />

                    <h2>Who we are?</h2>
                    <p>
                      MedTrack has been providing you with genuine medicines
                      round-the-clock, through 24-hour pharmacies. <br />
                      And now through MedTrack, we intend to make your lives
                      easier – by getting your medicines delivered to you.{" "}
                      <br />
                      Yes, no more stepping out to get your medicines, no more
                      standing in long queues, no more worrying about the
                      genuineness of medicines, no more sweat!
                    </p>

                    <h2>Services</h2>
                    <p>
                      Super-fast deliveries. In select cities, deliveries are
                      done in as less as 1 day
                      <br />
                      Largest pharmacy chain in India
                      <br />
                      Attractive deals on medicines and other FMCG products
                      <br />
                      Get Health Credits on purchases (not applicable on
                      discounted products)
                      <br />
                      Prescriptions can be uploaded directly to place an order
                      <br />
                      Option to consult with a pharmacologist to check medicine
                      interactions
                      <br />
                      Wide range of healthcare products to choose from Only
                      genuine and top-quality products delivered.
                      <br />
                    </p>

                    <h2>lorem!</h2>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                      sed do eiusmod tempor incididunt <br />
                      ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                      quis nostrud exercitation ullamco laboris <br />
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure
                      dolor in reprehenderit in voluptate velit <br />
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <br />
                    <br />
                  </div>

                  <br />
                </div>
              </div>
            }
            <br></br>
            <br></br>
          </div>
        </div>
      ) : (
        swal({
          icon: "error",
          text: "You are not logged in!",
          type: "error",
          timer: 3000,
        }).then(function () {
          window.location.href = "/login-page";
        })
      )}
    </>
  );
}

export default AboutUs;
