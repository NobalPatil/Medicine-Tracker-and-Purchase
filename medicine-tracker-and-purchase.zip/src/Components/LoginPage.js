import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "../CSS/LoginPage.css";
import { useState } from "react";
import axios from "axios";
import swal from "sweetalert";
import { Link } from "react-router-dom";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");

  const regex =
    /^([a-zA-Z0-9_\.\-\ ])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

  const handleForm = (e) => {
    e.preventDefault();
    if (email === "") {
      swal("Error!", "Please enter valid details", "error");
    } else if (!regex.test(email)) {
      swal("Error!", "Please enter valid email address", "error");
    } else if (password == "") {
      swal("Error!", "Please enter password", "error");
    } else if (password.length < 8 || password.length > 20) {
      swal("Error!", "Password length is min 8 and max length is 20", "error");
    } else {
      checkUser();
    }
  };

  const checkUser = async () => {
    let user = { emailId: email, password: password };

    if (role === "admin") {
      const res = await axios
        .post("http://localhost:8081/login-admin", user)
        .catch(() =>
          swal(
            "Error",
            "Something went wrong, please try after some time",
            "error",
            {
              timer: 2000,
            }
          )
        );

      if (res.data != "") {
        localStorage.setItem("adminId", res.data.adminId);
        swal("success", "Successfully Login, Welcome Admin!!", "success", {
          timer: 2000,
        }).then(() => (window.location.href = "/admin-home"));
      } else {
        swal(
          "Invalid Email Id or Password",
          "Please enter valid details",
          "error",
          {
            timer: 2000,
          }
        );
      }
    } else if (role === "customer") {
      const res = await axios
        .post("http://localhost:8081/login-customer", user)
        .catch(() =>
          swal(
            "Error",
            "Something went wrong, please try after some time",
            "error",
            {
              timer: 2000,
            }
          )
        );

      if (res.data != "") {
        localStorage.setItem("customer", JSON.stringify(res.data));
        swal("success", "Successfully Login, Welcome Customer!!", "success", {
          timer: 2000,
        }).then(() => (window.location.href = "/customer-home"));
      } else {
        swal(
          "Invalid Email Id or Password",
          "Please enter valid details",
          "error",
          {
            timer: 2000,
          }
        );
      }
    } else if (role === "pharmacist") {
      const res = await axios
        .post("http://localhost:8081/login-pharmacist", user)
        .catch(() =>
          swal(
            "Error",
            "Something went wrong, please try after some time",
            "error",
            {
              timer: 2000,
            }
          )
        );

      if (res.data != "") {
        localStorage.setItem("pharmacist", JSON.stringify(res.data));
        swal("success", "Successfully Login, Welcome Pharmacist!!", "success", {
          timer: 2000,
        }).then(() => (window.location.href = "/pharmacist-home"));
      } else {
        swal(
          "Invalid Email Id or Password",
          "Please enter valid details",
          "error",
          {
            timer: 2000,
          }
        );
      }
    } else {
      swal("User Role", "Please select your role !", "error", {
        timer: 2000,
      });
    }
  };

  return (
    <>
      <div class="main">
        <div>
          <div class="row">
            <div class="col-2 mt-3 "></div>
            <div class="col-8 mt-3">
              <div class="row">
                <div class="d-flex justify-content-center">
                  <form class="Registration-form">
                    <br />
                    <br />
                    <div className="d-flex justify-content-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="50"
                        height="50"
                        fill="currentColor"
                        class="bi bi-person-fill"
                        viewBox="0 0 16 16"
                      >
                        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                      </svg>
                    </div>
                    <br />
                    <div
                      class="inside-form mt-3"
                      style={{ color: "black" }}
                    ></div>
                    <div class="row">
                      <div class="col-sm-4">
                        <input
                          type="radio"
                          class="btn-check"
                          name="options"
                          id="option1"
                          value="admin"
                          onChange={(e) => {
                            setRole(e.target.value);
                          }}
                        />
                        <label class="btn btn-warning" for="option1">
                          Admin
                        </label>
                      </div>
                      <div class="col-sm-4">
                        <input
                          type="radio"
                          class="btn-check"
                          name="options"
                          id="option2"
                          value="customer"
                          onChange={(e) => {
                            setRole(e.target.value);
                          }}
                        />
                        <label class="btn btn-warning" for="option2">
                          Customer
                        </label>
                      </div>
                      <div class="col-sm-4">
                        <input
                          type="radio"
                          class="btn-check"
                          name="options"
                          id="option3"
                          value="pharmacist"
                          onChange={(e) => {
                            setRole(e.target.value);
                          }}
                        />
                        <label class="btn btn-warning" for="option3">
                          Pharmacist
                        </label>
                      </div>
                    </div>
                    <div class="form-group">
                      <div>
                        <lable
                          id="inputGroup-sizing-lg"
                          style={{ height: 5, position: "left" }}
                        >
                          Email
                        </lable>
                      </div>
                      <input
                        type="email"
                        class="form-control m-2"
                        aria-label="Email"
                        name="adminEmail"
                        id="adminEmail"
                        aria-describedby="inputGroup-sizing-sm"
                        required
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    <div class="form-group">
                      <lable for="password" style={{ fontSize: "15px" }}>
                        Password
                      </lable>
                      <input
                        type="password"
                        class="form-control m-2"
                        aria-label="password"
                        name="adminPass"
                        id="adminPass"
                        size="8"
                        aria-describedby="inputGroup-sizing-sm"
                        required
                        onChange={(e) => setPassword(e.target.value)}
                      />
                    </div>
                    <div class="form-group">
                      <button
                        class="btn btn-danger m-2"
                        type="button"
                        onClick={(checkUser, handleForm)}
                      >
                        Login
                      </button>
                      <br />
                      <Link
                        to="/pharmacist-registration"
                        class="btn btn-outline-primary m-2 "
                      >
                        Sign-Up as Pharmacist
                      </Link>
                      <Link
                        to="/customer-registration"
                        class="btn btn-outline-primary  m-2 "
                      >
                        &nbsp; &nbsp; Sign-Up as Customer &nbsp; &nbsp;
                      </Link>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-2 mt-2"></div>
      </div>
    </>
  );
}

export default Login;
